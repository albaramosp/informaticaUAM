from django.apps import AppConfig


class DatamodelConfig(AppConfig):
    name = 'datamodel'
