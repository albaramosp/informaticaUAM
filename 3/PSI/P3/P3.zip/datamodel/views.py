
def index(request):
    return "Hello friend"
