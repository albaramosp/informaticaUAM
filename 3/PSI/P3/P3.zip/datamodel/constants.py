"""
Fichero que almacena los valores que serán utilizados
como claves en diferentes diccionarios del proyecto.
@author: Alba Ramos Pedroviejo
"""

ERROR_MESSAGE_ID = 'msg_error'
CAT_GAMES_ID = 'as_cat'
MOUSE_GAMES_ID = 'as_mouse'
GAME_SELECTED_SESSION_ID = 'game_selected'
