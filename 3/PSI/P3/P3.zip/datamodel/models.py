"""
Fichero en el que se implementan los modelos de datos que darán
forma a la base de datos subyacente. Cada modelo tiene su propia
explicación.
"""
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.validators import ValidationError
from django.contrib.auth.models import User
from datamodel import tests
import django

"""
Se indica qué casillas son blancas para comprobar
si los jugadores están en casillas correctas.
"""
white = [0, 2, 4, 6, 9, 11, 13, 15, 16, 18, 20, 22, 25, 27, 29, 31, 32, 34, 36,
         38, 41, 43, 45, 47, 48, 50, 52, 54, 57, 59, 61, 63]


"""
Modelo que define los tipos de estado que
puede tener el juego.
@author: Alba Ramos Pedroviejo
"""


class GameStatus(models.Model):
    CREATED = 'Created'  # esperando al ratón
    ACTIVE = 'Active'  # ambos jugadores conectados
    FINISHED = 'Finished'


"""
Modelo que define el comportamiento que tendrá
el juego. Se especifican relaciones inversas
hacia los jugadores. Se utilizan validadores
para comprobar los valores de las celdas de
cada jugador. Las funciones sobrescritas se
comentan individualmente.
@author: Alba Ramos Pedroviejo
"""


class Game(models.Model):
    MIN_CELL = 0
    MAX_CELL = 63

    cat_user = models.ForeignKey(User, on_delete=models.CASCADE,
                                 related_name="games_as_cat")

    # Un juego es válido aunque solo tenga gato
    mouse_user = models.ForeignKey(User, on_delete=models.CASCADE,
                                   related_name="games_as_mouse", blank=True,
                                   null=True)
    cat_turn = models.BooleanField(default=True, null=False)
    status = models.CharField(default=GameStatus.CREATED,
                              null=False, max_length=20)

    cat1 = models.IntegerField(default=0, null=False,
                               validators=[MinValueValidator(MIN_CELL),
                                           MaxValueValidator(MAX_CELL)])

    cat2 = models.IntegerField(default=2, null=False,
                               validators=[MinValueValidator(MIN_CELL),
                                           MaxValueValidator(MAX_CELL)])

    cat3 = models.IntegerField(default=4, null=False,
                               validators=[MinValueValidator(MIN_CELL),
                                           MaxValueValidator(MAX_CELL)])

    cat4 = models.IntegerField(default=6, null=False,
                               validators=[MinValueValidator(MIN_CELL),
                                           MaxValueValidator(MAX_CELL)])

    mouse = models.IntegerField(default=59, null=False,
                                validators=[MinValueValidator(MIN_CELL),
                                            MaxValueValidator(MAX_CELL)])

    """
    Comprueba que la celda a la que se mueve el jugador
    sea blanca y cambia el estado del juego cuando se
    une el ratón.
    @author: Alba Ramos Pedroviejo
    """
    def save(self, *args, **kwargs):
        # Transición entre estados cuando se une el ratón
        if self.mouse_user and self.cat_user \
                and self.status == GameStatus.CREATED:
            self.status = GameStatus.ACTIVE

        if self.cat1 not in white or self.cat2 not in white \
                or self.cat3 not in white or self.cat4 not in white or \
                self.mouse not in white:
            raise ValidationError(tests.MSG_ERROR_INVALID_CELL)

        super(Game, self).save(*args, **kwargs)

    """
    Comprueba los campos del juego para mostrar sus datos
    por pantalla.
    @author: Alba Ramos Pedroviejo
    """
    def __str__(self):
        string = "(" + str(self.id) + ", " + self.status + ")\t"

        if self.cat_turn:
            string = string + "Cat [X]"
        else:
            string = string + "Cat [ ]"

        string = string + " " + str(self.cat_user) + "(" \
            + str(self.cat1) + ", " + str(self.cat2) + ", " \
            + str(self.cat3) + ", " + str(self.cat4) + ")"

        if self.mouse_user:
            if self.cat_turn:
                string = string + " --- Mouse [ ] "
            else:
                string = string + " --- Mouse [X] "

            string = string + str(self.mouse_user) \
                + "(" + str(self.mouse) + ")"

        return string


"""
Modelo que define cómo se tratarán los movimientos
en el juego. Se crea una relación inversa hacia game
que creará en esa tabla un campo moves. Se comenta
cada función individualmente.
@author: Alba Ramos Pedroviejo
"""


class Move(models.Model):
    origin = models.IntegerField(null=False)
    target = models.IntegerField(null=False)

    # related_name makes Game have a Move attribute with that name.
    # By default, Game will have moves_set, but we can override that name
    game = models.ForeignKey(Game, on_delete=models.CASCADE,
                             related_name="moves")
    player = models.ForeignKey(User, on_delete=models.CASCADE)

    date = models.DateField(null=False, default=django.utils.timezone.now)

    """
    Comprueba que un movimiento de gato sea válido.
    Para ello, comprueba que, si se está en un
    extremo del tablero, no se avance erróneamente.
    Comprueba también que la casilla destino no
    esté ocupada y que el origen del movimiento se
    corresponda con la posición real del jugador.
    @author: Alba Ramos Pedroviejo
    """
    def check_cat_mov(self):
        # extremo izdo del tablero
        if self.origin % 8 == 0:
            if self.target == self.origin+7:
                return False

        # extremo dcho del tablero
        if self.origin % 8 == 7:
            if self.target == self.origin + 9:
                return False

        # casilla ocupada
        if self.target == self.game.__getattribute__('cat1') or \
                self.target == self.game.__getattribute__('cat2') or \
                self.target == self.game.__getattribute__('cat3') or \
                self.target == self.game.__getattribute__('cat4') or \
                self.target == self.game.__getattribute__('mouse'):
            return False

        if self.origin == self.game.__getattribute__("cat1") or \
                self.origin == self.game.__getattribute__("cat2") or \
                self.origin == self.game.__getattribute__("cat3") or \
                self.origin == self.game.__getattribute__("cat4"):
            if self.target == (self.origin + 9) or \
                    self.target == (self.origin + 7):
                return True
            return False
        return False

    """
    Comprueba que un movimiento de ratón sea válido.
    Para ello, comprueba que, si se está en un
    extremo del tablero, no se avance erróneamente.
    Comprueba también que la casilla destino no
    esté ocupada y que el origen del movimiento se
    corresponda con la posición real del jugador.
    @author: Alba Ramos Pedroviejo
    """
    def check_mouse_mov(self):
        # extremo izdo del tablero
        if self.origin % 8 == 0:
            if (self.target == self.origin + 7) or \
                    (self.target == self.origin - 9):
                return False

        # extremo dcho del tablero
        if self.origin % 8 == 7:
            if (self.target == self.origin+9) or \
                    (self.target == self.origin-7):
                return False

        # casilla ocupada
        if self.target == self.game.__getattribute__("cat1") or \
                self.target == self.game.__getattribute__("cat2") or \
                self.target == self.game.__getattribute__("cat2") or \
                self.target == self.game.__getattribute__("cat4") or \
                self.target == self.game.__getattribute__("mouse"):
            return False

        if self.origin == self.game.__getattribute__("mouse"):
            if self.target == (self.origin - 9) or \
                    self.target == (self.origin - 7) or \
                    self.target == (self.origin + 9) or \
                    self.target == (self.origin + 7):
                return True
            return False

        return False

    """
    Comprueba que un juego sea válido, que el movimiento
    no se salga del tablero, que sea correcto para un
    tipo de jugador y que sea el turno adecuado antes
    de realizar un movimiento. Tras mover, actualiza
    la información del juego.
    @author: Alba Ramos Pedroviejo
    """
    def save(self, *args, **kwargs):
        if self.player.username == "no_player":
            raise ValidationError(tests.MSG_ERROR_MOVE)

        # No permitir movimientos en un juego no válido
        if GameStatus.ACTIVE != self.game.__getattribute__('status'):
            raise ValidationError(tests.MSG_ERROR_MOVE)

        # No permitir movimientos fuera del tablero
        if self.target < Game.MIN_CELL or self.target > Game.MAX_CELL:
            raise ValidationError(tests.MSG_ERROR_MOVE)

        # No permitir movimientos no asociados a cada tipo de jugador
        # No permitir movimientos fuera de turno
        if self.player == self.game.__getattribute__('cat_user'):
            if not self.check_cat_mov() or \
                    self.game.__getattribute__("cat_turn") is False:
                raise ValidationError(tests.MSG_ERROR_MOVE)

            if self.origin == self.game.__getattribute__('cat1'):
                self.game.__setattr__('cat1', self.target)

            if self.origin == self.game.__getattribute__('cat2'):
                self.game.__setattr__('cat2', self.target)

            if self.origin == self.game.__getattribute__('cat3'):
                self.game.__setattr__('cat3', self.target)

            if self.origin == self.game.__getattribute__('cat4'):
                self.game.__setattr__('cat4', self.target)

            self.game.__setattr__('cat_turn', False)

        if self.player == self.game.__getattribute__('mouse_user'):
            if not self.check_mouse_mov() or \
                    self.game.__getattribute__("cat_turn") is True:
                raise ValidationError(tests.MSG_ERROR_MOVE)
            self.game.__setattr__('mouse', self.target)
            self.game.__setattr__('cat_turn', True)

        self.game.save()
        super(Move, self).save()

    """
    Crea un string para mostrar los datos de
    un movimiento por pantalla.
    @author: Alba Ramos Pedroviejo
    """
    def __str__(self):
        string = "Movimiento desde %d hacia %d" % \
                 (self.origin, self.target)

        if self.game.__getattribute__("cat_turn") is True:
            string = string + "-->en el turno del gato"
        else:
            string = string + "-->en el turno del raton"

        if self.game.__getattribute__("cat_user") == self.player:
            string = string + "-->se va a mover al gato"
        else:
            string = string + "-->se va a mover al raton"

        return string


"""
Manager del modelo counter, define las funciones de las que
dispondra Counter.
@author: Javier Lozano Almeda
"""


class CounterManager(models.Manager):
    """
    Esta funcion comprueba si ya hay algun counter en la base
    de datos y lo coge. En caso de no existir se crea un nuevo
    counter en la base de datos. Una vez se tiene counter, se
    aumenta en uno el valor del cunter, se     guarda en la
    base de datos con el valor actualizado y se devuelve el valor.
    @author: Javier Lozano Almeda
    """
    def inc(self):
        try:
            counter = Counter.objects.get(id=1)

        except Counter.DoesNotExist:
            counter = Counter(id=1)
        counter.value += 1
        super(Counter, counter).save()
        return counter.value

    """
    Esta funcion comprueba si ya hay algun counter en la base de
    datos y lo coge. En caso de no existir se crea un nuevo counter
    en la base de datos. Una vez se tiene cauter, se devuelve el valor.
    @author: Javier Lozano Almeda
    """
    def get_current_value(self):
        try:
            counter = Counter.objects.get(id=1)

        except Counter.DoesNotExist:
            counter = Counter(id=1)
            super(Counter, counter).save()

        return counter.value


"""
Modelo que almacena los peticiones globales que se han hecho
al servidor. Este modelo sigue un un patron singletone, por
lo que se tendra una unica intancia.
Este modelo no tiene funcion str debeido a que __str__
ni __repre__ no nos han funcionado.
@author: Javier Lozano Almeda
"""


class Counter(models.Model):
    value = models.IntegerField(default=0, null=True, blank=True)

    objects = CounterManager()

    def save(self, *args, **kwargs):
        raise ValidationError(tests.MSG_ERROR_NEW_COUNTER)
