from django.apps import AppConfig


class LogicConfig(AppConfig):
    name = 'logic'
