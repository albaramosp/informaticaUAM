from django.urls import path
from logic import views

app_name = 'logic'

LOGIN_URL = 'logic:login'

urlpatterns = [
    path('index/', views.index, name='index'),
    path('', views.index, name='landing'),
    path('login', views.user_login, name='login'),
]
