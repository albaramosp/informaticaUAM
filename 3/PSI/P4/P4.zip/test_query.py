"""
Ficehro que prueba la implementación del modelo de datos,
comprobando que los juegos y movimientos se crean y se
guardan en la base de datos correctamente.

@author: Alba Ramos
"""
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                      'ratonGato.settings')

# causes flake8 warning, but needed in this order
import django
django.setup()

from datamodel.models import Game, Move
from django.contrib.auth.models import User


def test():
    test_id = 10
    cat_player = User.objects.get_or_create(id=test_id,
                                            username="cat_%d" % test_id)[0]
    print("Creado gato")

    test_id = 11
    mouse_player = User.objects.get_or_create(id=test_id,
                                              username="mouse_%d" % test_id)[0]
    print("Creado raton")

    game = Game(cat_user=cat_player)
    game.save()
    print("Creado juego con solo el gato")

    cont = 0
    game_less_id = game

    """Search for all the games with only one player"""
    for g in Game.objects.all():
        print("Analizando juego: " + str(g))
        if not g.mouse_user:
            cont = cont+1
            if g.id < game_less_id.id:
                game_less_id = g

    print("Juegos con un solo jugador en la base: %d" % cont)

    game_less_id.mouse_user = mouse_player
    game_less_id.save()

    print("Se va a comenzar una partida: " + str(game_less_id))

    Move.objects.create(game=game_less_id,
                        player=cat_player, origin=2, target=11)
    print("Movimiento realizado: " + str(game_less_id))
    Move.objects.create(game=game_less_id,
                        player=mouse_player, origin=59, target=52)
    print("Movimiento realizado: " + str(game_less_id))


# Start execution here!
if __name__ == '__main__':
    print('Starting test_query script...')
    test()
