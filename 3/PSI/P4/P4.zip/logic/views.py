"""
Fichero que define el comportamiento asociado a cada url solicitada
dentro de la aplicación.
Cada función cuenta con su propia explicación comentada.
"""

from django.shortcuts import render, redirect
from django.http import Http404
from django.http import HttpResponseForbidden, HttpResponseNotFound
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from datamodel.models import Counter, CounterErrors, GameStatus, Game, Move
from logic.forms import LoginForm, SignupForm, MoveForm
from datamodel import constants
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import JsonResponse


def anonymous_required(f):
    def wrapped(request):
        if request.user.is_authenticated:
            return HttpResponseForbidden(errorHTTP
                                         (request,
                                          exception="Action restricted to "
                                          "anonymous users"))
        else:
            return f(request)
    return wrapped


def errorHTTP(request, exception=None):
    context_dict = {}
    context_dict[constants.ERROR_MESSAGE_ID] = exception
    return render(request, "mouse_cat/error.html", context_dict)


"""
Define la página inicial de la aplicación
@author: Alba Ramos Pedroviejo
"""


def index(request):
    return render(request, 'mouse_cat/index.html')


"""
Define cómo se valida el  logueo de un usuario. Si el
método es un post, se valida la infromación y se
autentica al usuario utilizando el sistema de Django.
En caso de errores, se informa en el propio formulario
devuelto.
También inicia el contador de sesión.
@author: Alba Ramos Pedroviejo
"""
@anonymous_required
def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)

        if user:
            if user.is_active:
                login(request, user)
                request.session["counter_session"] = 0
                return redirect(reverse('logic:index'))
            else:
                return render(request, 'mouse_cat/error.html',
                              {'msg_error': "Your account is disabled."})
        else:
            user_form = LoginForm(request.POST or None)
            user_form.errors['username'] = None
            user_form.add_error(None, "Username/password is not valid")

            return render(request, 'mouse_cat/login.html',
                          {'user_form': user_form, 'error': 1})
    else:
        user_form = LoginForm()
        return render(request, 'mouse_cat/login.html',
                      {'user_form': user_form})


"""
Función que elimmina la sesión del usuario actual y resetea
el contador asociado a la sesión.
@author: Alba Ramos Pedroviejo
"""
@login_required
def user_logout(request):
    username = request.user.username
    logout(request)
    request.session["counter_session"] = 0
    return render(request, 'mouse_cat/logout.html', {'user': username})


"""
Función que da de alta en el sistema a un nuevo usuario.
Llama a los validadores de contraseña para asegurar que
esta cumple con los requisitos solicitados.
En caso de errores, se informa en el propio formulario
devuelto.
También inicia el contador de sesión.
@author: Alba Ramos Pedroviejo
"""
@anonymous_required
def signup(request):
    if request.method == 'POST':
        user_form = SignupForm(data=request.POST)

        if user_form.is_valid():
            pass1 = request.POST.get('password')
            pass2 = request.POST.get('password2')

            if pass1 == pass2:
                try:
                    validate_password(pass1, request.POST.get('username'))
                except ValidationError as e:
                    user_form = SignupForm(request.POST or None)
                    user_form.add_error(None, e)
                    return render(request, 'mouse_cat/signup.html',
                                  {'user_form': user_form, 'error': 1})

                user = user_form.save()
                user.set_password(user.password)
                user.save()
                login(request, user)
                request.session["counter_session"] = 0
                return redirect(reverse('logic:index'))
            else:
                user_form = SignupForm(request.POST or None)
                user_form.add_error(None,
                                    "Password and Repeat "
                                    "password are not the same")
                return render(request, 'mouse_cat/signup.html',
                              {'user_form': user_form, 'error': 1})

        else:
            user_form = SignupForm(request.POST or None)
            return render(request, 'mouse_cat/signup.html',
                          {'user_form': user_form})
    else:
        user_form = SignupForm()
        return render(request, 'mouse_cat/signup.html',
                      {'user_form': user_form})


"""
Función que incrementa o crea los contadores tanto
global como de sesión.
@author: Javier Lozano Almeda
"""


def counter(request):
    if 'counter_session' in request.session:
        request.session["counter_session"] += 1
    else:
        request.session["counter_session"] = 1

    counter_session = request.session["counter_session"]
    counter_global = Counter.objects.inc()
    return render(request, 'mouse_cat/counter.html',
                  {'counter_session': counter_session,
                   'counter_global': counter_global})


"""
Función que muestra el contador de errores
@author: Javier Lozano Almeda
"""


def counter_errors(request):
    counter_error = CounterErrors.objects.get_current_value()
    return render(request, 'mouse_cat/counter_errors.html',
                  {'counter_error': counter_error})


"""
Función que crea un nuevo juego, estableciendo como
jugador gato al usuario que lo crea.
@author: Javier Lozano Almeda
"""
@login_required
def create_game(request):
    game = Game(cat_user=request.user)
    game.save()

    return render(request,
                  'mouse_cat/new_game.html',
                  {'game': game})


"""
Función que permite al usuario unirse como ratón al juego
de mayor id que no tenga ratón asociado, lanzando un error
si no fuera posible encontrar un juego así.
@author: Javier Lozano Almeda
"""
@login_required
def join_game(request, game_id=None):

    if request.method == 'GET' and game_id:
        try:
            game = Game.objects.get(id=game_id)
        except Game.DoesNotExist:
            CounterErrors.objects.inc()
            raise Http404("The requested game does not exist.")

        if game.status != GameStatus.CREATED:
            CounterErrors.objects.inc()
            raise Http404("The requested game is not waiting for a mouse.")

    else:
        games = Game.objects.filter(mouse_user__isnull=True)\
                .exclude(cat_user=request.user)
        if len(games) == 0:
            return render(request, 'mouse_cat/join_game.html',
                          {'msg_error': "There is no available games"})

        game = games.latest('id')

    game.mouse_user = request.user
    game.save()
    return render(request, 'mouse_cat/join_game.html',
                  {'game': game})


"""
Función que permite al usuario seleccionar alguno de los
juegos a los que se ha unido o ha creado para jugar. Solo
es accesible con el metodo GET. El juego elegido debe estar
activo, existir y contener al usuario como jugador
(condiciones en los test que no se darán en el juego
visual).
Si el id de juego no se ha especificado en la URL, se
muestra un listado con los juegos disponibles para el
jugador, mientras que si sí se especifica, se lanza ese
juego.
el numero de pagina a mostrar por categoria se puede
cambiar en constans.py
@author: Javier Lozano Almeda
"""
@login_required
def select_game(request, game_id=None):
    user = request.user
    opcion = None

    if request.method == 'GET' and game_id:
        try:
            game = Game.objects.get(id=game_id)
        except Game.DoesNotExist:
            CounterErrors.objects.inc()
            raise Http404("The requested game does not exist.")

        if game.cat_user != user and game.mouse_user != user:
            CounterErrors.objects.inc()
            raise Http404("this game is not yours.")

        request.session[constants.GAME_SELECTED_SESSION_ID] = game_id

        if game.status == GameStatus.ACTIVE:
            return redirect(reverse('show_game'))
        if game.status == GameStatus.FINISHED:
            return redirect(reverse('play_game'))

    else:
        filtro = None
        catPage = 1
        mousePage = 1
        openPage = 1
        finishedPage = 1

        gamesCat = Game.objects.filter(cat_user=user)\
            .exclude(status=GameStatus.FINISHED)\
            .exclude(status=GameStatus.CREATED)
        gamesMouse = Game.objects.filter(mouse_user=user)\
            .exclude(status=GameStatus.FINISHED)\
            .exclude(status=GameStatus.CREATED)
        openGames = Game.objects.filter(status=GameStatus.CREATED)\
            .exclude(cat_user=user)

        query = Q(status=GameStatus.FINISHED)
        query.add(Q(Q(cat_user=user) | Q(mouse_user=user)), Q.AND)

        finishedGames = Game.objects.filter(query)

        catPaginator = Paginator(gamesCat, constants.ITEMS_BY_PAGE)
        mousePaginator = Paginator(gamesMouse, constants.ITEMS_BY_PAGE)
        openPaginator = Paginator(openGames, constants.ITEMS_BY_PAGE)
        fishedPaginator = Paginator(finishedGames, constants.ITEMS_BY_PAGE)

        if request.method == 'POST':
            page = request.POST.get('page')
            action = request.POST.get('action')

            if action == 'filter':
                filtro = request.POST.get('filter')
                opcion = filtro

            else:
                catPage = int(request.POST.get('as_catCurrent'))
                mousePage = int(request.POST.get('as_mouseCurrent'))
                openPage = int(request.POST.get('openCurrent'))
                finishedPage = int(request.POST.get('finishedCurrent'))
                print(action)
                print(page)
                print(request.POST.get('openCurrent'))
                if page == "as_cat":
                    if action == "previous":
                        catPage = catPage - 1
                    elif action == "next":
                        catPage = catPage + 1
                    if action == "first":
                        catPage = 1
                    elif action == "last":
                        catPage = catPaginator.num_pages

                elif page == "as_mouse":
                    if action == "previous":
                        mousePage = mousePage - 1
                    elif action == "next":
                        mousePage = mousePage + 1
                    if action == "first":
                        mousePage = 1
                    elif action == "last":
                        mousePage = mousePaginator.num_pages

                elif page == "opengames":
                    if action == "previous":
                        openPage = openPage - 1
                    elif action == "next":
                        openPage = openPage + 1
                    if action == "first":
                        openPage = 1
                    elif action == "last":
                        openPage = openPaginator.num_pages

                elif page == "opengames":
                    if action == "previous":
                        finishedPage = finishedPage - 1
                    elif action == "next":
                        finishedPage = finishedPage + 1
                    if action == "first":
                        finishedPage = 1
                    elif action == "last":
                        finishedPage = fishedPaginator.num_pages

        context_dict = {}

        if len(gamesCat) != 0 and filtro != 'Finished' and filtro != 'Raton':
            paginatedCatGames = catPaginator.get_page(catPage)
            context_dict[constants.CAT_GAMES_ID] = paginatedCatGames

        if len(gamesMouse) != 0 and filtro != 'Gato' and filtro != 'Finished':
            paginatedMouseGames = mousePaginator.get_page(mousePage)
            context_dict[constants.MOUSE_GAMES_ID] = paginatedMouseGames

        if len(openGames) != 0 and filtro != 'Finished' and filtro != 'Raton':
            paginatedOpenGames = openPaginator.get_page(openPage)
            context_dict[constants.OPEN_GAMES_ID] = paginatedOpenGames

        if len(finishedGames) != 0 and filtro != 'Gato' and filtro != 'Raton':
            paginatedfinishedGames = fishedPaginator.get_page(finishedPage)
            context_dict[constants.FINISHED_GAMES_ID] = paginatedfinishedGames

        context_dict[constants.DROP_ID] = opcion

        return render(request, 'mouse_cat/select_game.html', context_dict)


"""
Función que permite visualizar el tablero de juego para el juego
seleccionado. Muestra también un formulario para realizar
movimientos si es el turno de ese jugador.
@author: Javier Lozano Almeda
"""
@login_required
def show_game(request):
    white = [0, 2, 4, 6, 9, 11, 13, 15, 16, 18, 20, 22, 25, 27, 29, 31, 32,
             34, 36, 38, 41, 43, 45, 47, 48, 50, 52, 54, 57, 59, 61, 63]
    print(request.user)
    if constants.GAME_SELECTED_SESSION_ID in request.session:
        try:
            game = Game.objects.get(id=request.session[constants
                                    .GAME_SELECTED_SESSION_ID])
        except Game.DoesNotExist:
            raise Http404("The requested game does not exist.")

        user = request.user
        move_form = None

        if (user == game.cat_user and game.cat_turn is True) \
                or (user == game.mouse_user and game.cat_turn is False):
            move_form = MoveForm()

        board = [0] * 64
        board[game.cat1] = 1
        board[game.cat2] = 1
        board[game.cat3] = 1
        board[game.cat4] = 1
        board[game.mouse] = -1

        return render(request, 'mouse_cat/game.html',
                      {'game': game, 'board': board,
                       'move_form': move_form, 'white': white})

    CounterErrors.objects.inc()
    raise Http404("No selected game.")


"""
Función que permite realizar movimientos al usuario y mostrar
el tablero tras el movimiento. Si un movimiento es inválido
por alguna razón determinada en el modelo, se añade un error
al formulario. Al realizar un movimiento, se comprueba si
alguno de los jugadores ha ganado la partida. Si esto
ocurriera se muestra un mensaje y se bloquea la partida
@author: Alba Ramos Pedroviejo
"""
@login_required
def move(request):
    if request.method == 'POST':
        white = [0, 2, 4, 6, 9, 11, 13, 15, 16, 18, 20, 22, 25,
                 27, 29, 31, 32, 34, 36, 38, 41, 43, 45, 47, 48,
                 50, 52, 54, 57, 59, 61, 63]
        print(request.user)
        if constants.GAME_SELECTED_SESSION_ID in request.session:
            try:
                game = Game.objects.get(id=request
                                        .session[constants
                                                 .GAME_SELECTED_SESSION_ID])
            except Game.DoesNotExist:
                CounterErrors.objects.inc()
                raise Http404("The requested game does not exist.")

            user = request.user
            origin = int(request.POST.get('origin'))
            target = int(request.POST.get('target'))

            board = [0] * 64
            board[game.cat1] = 1
            board[game.cat2] = 1
            board[game.cat3] = 1
            board[game.cat4] = 1
            board[game.mouse] = -1

            # Comprobamos si el juego ya ha finalizado
            if game.status == GameStatus.FINISHED:
                move_form = MoveForm(request.POST or None)
                move_form.add_error(None, "More move not allowed!!!")
                board = [0] * 64
                board[game.cat1] = 1
                board[game.cat2] = 1
                board[game.cat3] = 1
                board[game.cat4] = 1
                board[game.mouse] = -1
                return render(request, 'mouse_cat/game.html',
                              {'game': game, 'board': board,
                               'move_form': move_form, 'white': white})

            try:
                Move.objects.create(origin=origin,
                                    target=target, game=game, player=user)

                board = [0] * 64
                board[game.cat1] = 1
                board[game.cat2] = 1
                board[game.cat3] = 1
                board[game.cat4] = 1
                board[game.mouse] = -1

                # Comprobamos si el raton ha ganado la partida
                mouse_pos = int(game.mouse/8)
                cat_pos = game.cat1
                if game.cat2 < cat_pos:
                    cat_pos = game.cat2
                if game.cat3 < cat_pos:
                    cat_pos = game.cat3
                if game.cat4 < cat_pos:
                    cat_pos = game.cat4

                cat_pos = int(cat_pos/8)
                if mouse_pos < cat_pos:
                    move_form = MoveForm(request.POST or None)
                    move_form.add_error(None, "Game Finished,\
                                        Congrats mouse!!!")
                    game.status = GameStatus.FINISHED
                    game.save()
                    return render(request, 'mouse_cat/game.html',
                                  {'game': game, 'board': board,
                                   'move_form': move_form, 'white': white})

                # Comprobamos si el gato ha ganado la partida
                hunt_pos1 = game.mouse - 9 if game.mouse % 8 != 0 else - 1
                hunt_pos2 = game.mouse - 7 if game.mouse == ((int(game.mouse/8)+1)*8) - 1 else - 1
                hunt_pos3 = game.mouse + 7 if game.mouse % 8 != 0 else - 1
                hunt_pos4 = game.mouse + 9 if game.mouse == ((int(game.mouse / 8) + 1) * 8) - 1 else - 1

                if hunt_pos1 < 0 or hunt_pos1 > 63 or isCat(hunt_pos1, game):
                    if hunt_pos2 < 0 or hunt_pos2 > 63 or isCat(hunt_pos2, game):
                        if hunt_pos3 < 0 or hunt_pos3 > 63 or isCat(hunt_pos3, game):
                            if hunt_pos4 < 0 or hunt_pos4 > 63 or isCat(hunt_pos4, game):
                                move_form = MoveForm(request.POST or None)
                                move_form.add_error(None, "Game Finished, Congrats cat!!!")
                                game.status = GameStatus.FINISHED
                                game.save()
                                return render(request, 'mouse_cat/game.html',
                                              {'game': game, 'board': board,
                                               'move_form': move_form, 'white': white})

                return render(request, 'mouse_cat/game.html',
                              {'game': game, 'board': board, 'white': white})

            except ValidationError:
                move_form = MoveForm(request.POST or None)
                move_form.add_error(None, "Move not allowed")

                board = [0] * 64
                board[game.cat1] = 1
                board[game.cat2] = 1
                board[game.cat3] = 1
                board[game.cat4] = 1
                board[game.mouse] = -1
                return render(request, 'mouse_cat/game.html',
                              {'game': game, 'board': board,
                               'move_form': move_form, 'white': white})

        CounterErrors.objects.inc()
        raise Http404("No selected game.")
    return HttpResponseNotFound(errorHTTP(request,
                                          exception="Get no permitido"))


"""
Función que comprueba si en en una posicion recicibida
hay algun gato.
@author: Javier Lozano Almeda
"""


def isCat(cat, game):
    if cat == game.cat1 or cat == game.cat2 or cat == game.cat3\
       or cat == game.cat4:
        return True

    return False


"""
Función que permite visualizar la reproduccion de
una partida finalizada.
@author: Javier Lozano Almeda
"""
@login_required
def play_game(request):

    if constants.GAME_SELECTED_SESSION_ID in request.session:
        gameId = request.session[constants.GAME_SELECTED_SESSION_ID]
        try:
            game = Game.objects.get(id=gameId)
        except Game.DoesNotExist:
            CounterErrors.objects.inc()
            raise Http404("The requested game does not exist.")

        if game.status != GameStatus.FINISHED:
            CounterErrors.objects.inc()
            raise Http404("The requested game is not Finished.")

        user = request.user

        if game.cat_user != user and game.mouse_user != user:
            CounterErrors.objects.inc()
            raise Http404("this game is not yours.")

        request.session[constants.GAME_TO_PLAY] = gameId
        request.session[constants.GAME_PLAY_INDEX] = 0

        white = [0, 2, 4, 6, 9, 11, 13, 15, 16, 18, 20, 22, 25, 27, 29,
                 31, 32, 34, 36, 38, 41, 43, 45, 47, 48, 50, 52, 54, 57,
                 59, 61, 63]

        board = [0] * 64
        board[0] = 1
        board[2] = 1
        board[4] = 1
        board[6] = 1
        board[59] = -1
        game.cat_turn = True
        return render(request, 'mouse_cat/playGame.html',
                      {'game': game, 'board': board, 'white': white})
    CounterErrors.objects.inc()
    raise Http404("No selected game.")


"""
Función que permite visualizar la reproduccion de
una partida finalizada.
@author: Javier Lozano Almeda
"""
@login_required
def get_move(request):
    if request.method == 'POST':
        if constants.GAME_SELECTED_SESSION_ID in request.session:
            gameId = request.session[constants.GAME_SELECTED_SESSION_ID]
            try:
                game = Game.objects.get(id=gameId)
            except Game.DoesNotExist:
                CounterErrors.objects.inc()
                raise Http404("The requested game does not exist.")

            if game.status != GameStatus.FINISHED:
                CounterErrors.objects.inc()
                raise Http404("The requested game is not Finished.")

            if constants.GAME_PLAY_INDEX in request.session:
                index = request.session[constants.GAME_PLAY_INDEX]

            else:
                index = 0

            if 'shift' in request.POST:
                shift = request.POST.get('shift')

                moves = list(Move.objects.filter(game_id=gameId).order_by('id'))
                move = {}

                if shift == '-1':
                    index -= 1
                    if index < 0:
                        index = 0
                    move['origin'] = moves[index].target
                    move['target'] = moves[index].origin
                    move['previous'] = True if index > 0 else False
                    move['next'] = True if index < len(moves) else False
                    move['finished'] = True if index == len(moves) - 1 else False
                    move['error'] = None

                if index > len(moves):
                    CounterErrors.objects.inc()
                    raise Http404("No more moves.")

                if shift == '1':
                    move['origin'] = moves[index].origin
                    move['target'] = moves[index].target
                    move['previous'] = True if index >= 0 else False
                    move['next'] = True if index < len(moves) - 1 else False
                    move['finished'] = True if index == len(moves) - 1 else False
                    move['error'] = None

                    index += 1
                    if index > len(moves) - 1:
                        index = len(moves) - 1

                request.session[constants.GAME_PLAY_INDEX] = index
                return JsonResponse(move)

            else:
                CounterErrors.objects.inc()
                raise Http404("No game to play.")

        else:
            CounterErrors.objects.inc()
            raise Http404("No game to play.")
    else:
        CounterErrors.objects.inc()
        raise Http404("The server does not accept get pettitions.")
