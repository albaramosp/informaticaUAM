"""
Fichero que crea los formularios que se usarán en la aplicación
para registrar y permitir el inicio de sesión de los usuarios
y para realizar movimientos en un juego.

@author: Alba Ramos Pedroviejo
"""

from django import forms
from datamodel.models import Game, Move
from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class LoginForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'password')

    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)

        for fieldname in ['username', 'password']:
            self.fields[fieldname].help_text = None


class SignupForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    password2 = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'password', 'password2')

    def __init__(self, *args, **kwargs):
        super(SignupForm, self).__init__(*args, **kwargs)

        for fieldname in ['username', 'password', 'password2']:
            self.fields[fieldname].help_text = None


class MoveForm(forms.ModelForm):
    origin = models.IntegerField(null=False,
                                 validators=[MinValueValidator(Game.MIN_CELL),
                                             MaxValueValidator(Game.MAX_CELL)])
    target = models.IntegerField(null=False,
                                 validators=[MinValueValidator(Game.MIN_CELL),
                                             MaxValueValidator(Game.MAX_CELL)])

    class Meta:
        model = Move
        fields = ('origin', 'target')

    """
    Validación manual de los valores de origen y destino de un
    movimiento, necesarios para cuando un juego se crea manualmente en los test
    """
    def clean(self):
        cleaned = self.cleaned_data
        ori = cleaned.get("origin")
        target = cleaned.get("target")

        if ori < Game.MIN_CELL or ori > Game.MAX_CELL \
                or target < Game.MIN_CELL or target > Game.MAX_CELL:
            raise forms.ValidationError("Invalid cell")

        return cleaned

    """
    Establece los valores mínimo y máximo del
    widget para introducir el origen y el destino del movimiento
    """
    def __init__(self, *args, **kwargs):
        super(MoveForm, self).__init__(*args, **kwargs)
        self.fields['origin'].widget.attrs['min'] = Game.MIN_CELL
        self.fields['origin'].widget.attrs['max'] = Game.MAX_CELL
        self.fields['target'].widget.attrs['min'] = Game.MIN_CELL
        self.fields['target'].widget.attrs['max'] = Game.MAX_CELL
