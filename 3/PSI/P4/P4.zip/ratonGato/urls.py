"""
Fichero que mapea las urls que el cliente solicita
hacia las vistas que determinan el commportamiento
a realizar en cada una.

@author Alba Ramos Pedroviejo
"""
from django.contrib import admin
from django.urls import path
from logic import views
from django.urls import include
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('index/', views.index, name='index'),
    path('', views.index, name='landing'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('signup/', views.signup, name='signup'),
    path('counter/', views.counter, name='counter'),
    path('counter_errors/', views.counter_errors, name='counter_errors'),
    path('create_game/', views.create_game, name='create_game'),
    path('join_game/', views.join_game, name='join_game'),
    path('join_game/<int:game_id>', views.join_game, name='join_game'),
    path('select_game/', views.select_game, name='select_game'),
    path('select_game/<int:game_id>', views.select_game, name='select_game'),
    path('show_game/', views.show_game, name='show_game'),
    path('move/', views.move, name='move'),
    path('play_game/', views.play_game, name='play_game'),
    path('get_move/', views.get_move, name='get_move'),
    path('logic/', include('logic.urls')),
    path('admin/', admin.site.urls),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += static(settings.STATIC_URL,
                      document_root=settings.STATIC_ROOT)
