"""
Fichero que almacena los valores que serán utilizados
como claves en diferentes diccionarios del proyecto.
@author: Alba Ramos Pedroviejo
"""

ERROR_MESSAGE_ID = 'msg_error'
CAT_GAMES_ID = 'as_cat'
MOUSE_GAMES_ID = 'as_mouse'
OPEN_GAMES_ID = 'opengames'
FINISHED_GAMES_ID = 'finishedgames'
ITEMS_BY_PAGE = 3
GAME_SELECTED_SESSION_ID = 'game_selected'
GAME_TO_PLAY = 'game_to_play'
GAME_PLAY_INDEX = 'game_play_index'
DROP_ID = 'dropValue'