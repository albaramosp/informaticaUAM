"""
Fichero donde se añaden los modelos a la interfaz
del administrador para poder gestionarlos desde ahí.
@author: Javier Lozano Almeda
@author: Alba Ramos Pedroviejo
"""
from django.contrib import admin
from datamodel.models import Game, GameStatus, Move, Counter, CounterErrors

admin.site.register(Game)
admin.site.register(GameStatus)
admin.site.register(Move)
admin.site.register(Counter)
admin.site.register(CounterErrors)
