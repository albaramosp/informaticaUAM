"""
Fichero que implementa nuevos tests sobre las aplicaciones desarrolladas.
Cada test se explica individualmente.
"""

from django.core.exceptions import ValidationError
from . import tests
from .models import Game, GameStatus, Move


class MoveModelTests(tests.BaseModelTest):
    """
    Prueba que no se puedan mover jugadores hacia casillas
    que no les corresponden segun las especificaciones
    del enunciado para cada tipo de jugador.
    @author: Alba Ramos Pedroviejo
    """
    def test1(self):
        game = Game.objects.create(
            cat_user=self.users[0],
            mouse_user=self.users[1], status=GameStatus.ACTIVE)
        moves = [
            {"player": self.users[0], "origin": 0, "target": 8},
            {"player": self.users[1], "origin": 59, "target": 60},
            {"player": self.users[0], "origin": 2, "target": 3},
            {"player": self.users[0], "origin": 63, "target": 72},
        ]

        for move in moves:
            with self.assertRaisesRegex(ValidationError,
                                        tests.MSG_ERROR_MOVE):
                Move.objects.create(
                    game=game, player=move["player"],
                    origin=move["origin"], target=move["target"])

    """
    Prueba que se actualiza correctamente la posición
    de cada jugador, de forma que no se pueda volver
    a mover un jugador desde la casilla de la que partía.
    @author: Alba Ramos Pedroviejo
    """
    def test2(self):
        game = Game.objects.create(cat_user=self.users[0],
                                   mouse_user=self.users[1],
                                   status=GameStatus.ACTIVE)

        Move.objects.create(game=game,
                            player=self.users[0],
                            origin=0, target=9)

        with self.assertRaisesRegex(ValidationError, tests.MSG_ERROR_MOVE):
            Move.objects.create(game=game,
                                player=self.users[0], origin=0, target=9)

        Move.objects.create(game=game,
                            player=self.users[1], origin=59, target=50)

        with self.assertRaisesRegex(ValidationError, tests.MSG_ERROR_MOVE):
            Move.objects.create(game=game,
                                player=self.users[1], origin=59, target=50)

    """
        Prueba que se imprime correctamente
        un movimiento. El turno parece erróneo,
        pero es totalmente correcto, pues tras
        el movimiento se actualiza el turno.
        @author: Alba Ramos Pedroviejo
        """

    def test3(self):
        game = Game.objects.create(cat_user=self.users[0],
                                   mouse_user=self.users[1],
                                   status=GameStatus.ACTIVE)

        move = Move.objects.create(game=game,
                                   player=self.users[0],
                                   origin=0, target=9)
        self.assertEqual(
            str(move),
            "Movimiento desde 0 hacia 9-->"
            "en el turno del raton-->se va a mover al gato")

        move = Move.objects.create(game=game,
                                   player=self.users[1],
                                   origin=59, target=50)
        self.assertEqual(
            str(move),
            "Movimiento desde 59 hacia 50-->"
            "en el turno del gato-->se va a mover al raton")
