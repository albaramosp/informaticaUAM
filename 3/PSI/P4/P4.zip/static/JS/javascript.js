
var serverurl = ""
var reproductor
var stopFlag = false


function seturl(url){
  serverurl = url
}


$( function() {
  $( '.cat' ).draggable({
    helper: 'clone'
  });
} );
$( function() {
  $( '.mouse' ).draggable({
    helper: 'clone'
  });
} );

$( function() {
  $( '.chess_cell' ).droppable({
  accept: '.cat, .mouse',
  hoverClass: 'hovering',

  drop: function( ev, ui ) {
    var form = $('.moveForm')
    form.find("input[name*='origin']" ).val(ui.draggable.find("#dragForm").find("input[name*='origin']" ).val())
    form.find("input[name*='target']" ).val($(this).find("input[name*='cell_num']" ).val())
    
    
    form.submit()

  }
});
} );

function submitSelection(page,action){
  var form = $('.selctionForm')
  form.find("input[name*='page']" ).val(page)
  form.find("input[name*='action']" ).val(action)
  form.submit()
}


function stop(){
  mostrar('next')
  mostrar('previous')
  stopFlag = false
  clearInterval(reproductor);
}

function init(){
  ocultar('next')
  ocultar('previous')
  stopFlag = true
  reproductor = setInterval(function(){getmove('1')},2000);
}

function getmove(shift){
  //Creamos objeto XHTTP
  var xhttp = new XMLHttpRequest();
  //Recogemos respuesta y estado del servidor en callback
  xhttp.onreadystatechange = function (){
    if (xhttp.readyState == 4 && xhttp.status == 200){
      var move = JSON.parse(xhttp.responseText);
      var target = document.getElementById('cell_'+move['target']).querySelector('img');
      var origin = document.getElementById('cell_'+move['origin']).querySelector('img');
      var aux = target.src;
      target.src = origin.src;
      origin.src = aux;
      if(move['finished'] ){
        alert('El juego a terminado')
        stop();
      }
      if(move['next'] && stopFlag == false){
        mostrar('next')
      } else {
        ocultar('next')
      }
      if(move['previous'] && stopFlag == false){
        mostrar('previous')
      } else {
        ocultar('previous')
      }
    }
  }

  //Enviamos la peticion al servidor

  xhttp.open("POST", serverurl, true);
  xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhttp.setRequestHeader("X-CSRFToken", csrftoken);
  xhttp.send("shift="+shift);
}

function getCookie(name) {
  var cookieValue = null;
  if (document.cookie && document.cookie !== '') {
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
          var cookie = cookies[i].trim();
          // Does this cookie string begin with the name we want?
          if (cookie.substring(0, name.length + 1) === (name + '=')) {
              cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
              break;
          }
      }
  }
  return cookieValue;
}
var csrftoken = getCookie('csrftoken');

function mostrar(id){
  var elem = document.getElementById(id);
  elem.style.display = 'inline';
}

function ocultar(id){
  var elem = document.getElementById(id);
  elem.style.display = 'none';
}

  