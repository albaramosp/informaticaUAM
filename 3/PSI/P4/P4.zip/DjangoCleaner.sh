#!/bin/bash

echo
echo "Executing migrations cleaning script for datamodel. . ."
echo

find . -path "*/migrations/*.py" -not -name "__init__.py" -delete
find . -path "*/migrations/*.pyc"  -delete

rm db.sqlite3
python3 ./manage.py makemigrations datamodel 
python3 ./manage.py migrate datamodel

echo
echo "CLEANING TASKS COMPLETED!"
echo
